let slideIndex = 1;
exibirSlide(slideIndex);

const exibirSlide = (n) => {
    let i;
    let slides = document.getElementByClassName("slide");
    let dots = document.getElementByClassName("dot");

    if (n > slides.Length) {
        slideIndex = 1;
    }

    if (n < 1) {
        slideIndex = slides.Length;
    }

    for (slide of slides) {
        slide.style.display = "none";
    }

    for (dot of dots) {
        dot.className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += "active";
};

const mudarSlide = (n) => {
    exibirSlide(slideIndex += n);
};

const slideAtual = (n) => {
    exibirSlide(slideIndex = n);
};
